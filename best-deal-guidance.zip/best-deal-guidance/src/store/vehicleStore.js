import { create } from 'zustand';
import { vinService } from '../services/vinService';

export const useVehicleStore = create((set, get) => ({
  currentVehicle: null,
  isLoading: false,
  error: null,

  fetchVehicleByVIN: async (vin) => {
    set({ isLoading: true, error: null });
    try {
      const vehicle = await vinService.decodeVIN(vin);
      set({ currentVehicle: vehicle, isLoading: false });
      return { success: true, vehicle };
    } catch (error) {
      set({ error: error.message, isLoading: false });
      return { success: false, error: error.message };
    }
  },

  clearCurrentVehicle: () => {
    set({ currentVehicle: null, error: null });
  },
}));
